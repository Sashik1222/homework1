// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        int[] array = new int[2];
        array[0] = 10;
        array[1] = 20;
        for (int i = 0; i < array.length; i++) {
            System.out.println("element  " + i + ": " + array[i]);
        }
    }
}
